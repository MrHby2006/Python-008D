
nota_ingresada = int(input("Por favor ingrese una nota: "))

if nota_ingresada >= 90:
    print("Calificación: A")
elif nota_ingresada >= 80:
    print("Calificación: B")
elif nota_ingresada >= 70:
    print("Calificación: C")
elif nota_ingresada >= 60:
    print("Calificación: D")
else:
    print("Calificación: E")
