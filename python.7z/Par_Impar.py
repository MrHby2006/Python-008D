
for i in range(1, 21):
    if i % 2 == 0:
        print(f"{i} es par")
    else:
        print(f"{i} es impar")