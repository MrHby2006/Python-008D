
nombre = input("Ingrese su nombre: ")
edad = int(input("Ingrese su edad: "))

edad = edad + 1

#print("Su nombre es: " + nombre + " y su edad es: " + edad)
print(f"Su nombre es: {nombre} y su edad es: {edad}")