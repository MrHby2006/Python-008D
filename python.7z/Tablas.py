
print("Tablas")

numero = int(input("Introduce un número: "))

for i in range(1,11):
    resultado = numero * i
    print(f"{numero} x {i} = {resultado}")