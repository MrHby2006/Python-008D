
from random import randint

n1 = int(input("Ingrese el primer número: "))
n2 = int(input("Ingrese el segundo número: "))

num = randint(n1,n2)

print(f"El número random es : {num}")