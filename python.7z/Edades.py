
edad = int(input("Introduce tu edad: "))
if edad <= 12:
    print("Eres un infante")
elif 13 <= edad <= 19:
    print("Eres un adolescente")
else:
    print("Eres un adulto")